﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using ContactAPI.Interfaces;
using ContactAPI.Model;
using Microsoft.EntityFrameworkCore;

namespace ContactAPI.Repository
{
    public class ContactRepository : IContactRepository
    {

        #region Injected Members
        private readonly ContactDBContext _dbContext;

        #endregion
        public ContactRepository(ContactDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<Contact> CreateContact(Contact contactDetails)
        {
            if (contactDetails != null)
            {
                Contact contact = new Contact();
                contact.FirstName = contactDetails.FirstName;
                contact.LastName = contactDetails.LastName;
                contact.PhoneNumber = contactDetails.PhoneNumber;
                contact.EmailAddress = contactDetails.EmailAddress;
                contact.Status = contactDetails.Status;
                await _dbContext.SaveChangesAsync().ConfigureAwait(false);
            }
            return contactDetails;
        }

        
        async Task<IList<Contact>> IContactRepository.GetAllContacts()
        {
            List<Contact> contactList = new List<Contact>();

            var dbContactDetailList = await _dbContext.Contacts.ToListAsync().ConfigureAwait(false);

            if (dbContactDetailList != null && dbContactDetailList.Count > 0)
            {
                Parallel.ForEach(dbContactDetailList, x =>
                {
                    Contact contact = new Contact();

                    contact.ContactID = x.ContactID;
                    contact.FirstName = x.FirstName;
                    contact.LastName = x.LastName;
                    contact.PhoneNumber = x.PhoneNumber;
                    contact.Status = x.Status;
                    contactList.Add(contact);

                });
                return contactList;
            }
            else
            {
                return contactList;
            }
        }
        public Task<Contact> DeleteContact(string ContactID)
        {
            throw new NotImplementedException();
        }

        public Contact GetContact(string contactID)
        {
            throw new NotImplementedException();
        }

        public Task<Contact> UpateContact(Contact contact)
        {
            throw new NotImplementedException();
        }
    }
}